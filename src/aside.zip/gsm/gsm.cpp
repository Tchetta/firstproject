#include "gsm.h"
#include "../aside/aside.h"

const char simPIN[]   = "";
String SMS_Message;

#define TINY_GSM_MODEM_SIM800
#define TINY_GSM_RX_BUFFER 1024

#include <Wire.h>
#include <TinyGsmClient.h>

// TTGO T-Call pin definitions
#define MODEM_RST        5
#define MODEM_PWKEY      4
#define MODEM_POWER_ON   23
#define MODEM_TX         27
#define MODEM_RX         26
#define I2C_SDA          21
#define I2C_SCL          22

#define SerialAT Serial1
#define SerialMon Serial

#ifdef DUMP_AT_COMMANDS
#include <StreamDebugger.h>
StreamDebugger debugger(SerialAT, SerialMon);
TinyGsm modem(debugger);
#else
TinyGsm modem(SerialAT);
#endif

#define IP5306_ADDR          0x75
#define IP5306_REG_SYS_CTL0  0x00

bool callActive = false;
unsigned long callStartTime = 0;
const unsigned long callDuration = 30000; // 30 seconds

char smsBuffer[250]; // Buffer to store SMS messages

bool setPowerBoostKeepOn(int en) {
  Wire.beginTransmission(IP5306_ADDR);
  Wire.write(IP5306_REG_SYS_CTL0);
  Wire.write(en ? 0x37 : 0x35);
  return Wire.endTransmission() == 0;
}

void powerOnGSM() {
  pinMode(MODEM_PWKEY, OUTPUT);
  pinMode(MODEM_RST, OUTPUT);
  pinMode(MODEM_POWER_ON, OUTPUT);
  digitalWrite(MODEM_PWKEY, LOW);
  digitalWrite(MODEM_RST, HIGH);
  digitalWrite(MODEM_POWER_ON, HIGH);
}

void setupGSM() {
  Wire.begin(I2C_SDA, I2C_SCL);
  bool isOk = setPowerBoostKeepOn(1);
  SerialMon.println(String("IP5306 KeepOn ") + (isOk ? "OK" : "FAIL"));

  powerOnGSM();

  SerialAT.begin(115200, SERIAL_8N1, MODEM_RX, MODEM_TX);
  delay(3000);

  SerialMon.println("Initializing modem...");
  modem.restart();
  SerialMon.println("Modem restart finished!");

  int simStatus = modem.getSimStatus();
  if (simStatus != 3) {
    modem.simUnlock(""); // Add your PIN if needed
  }

  waitForNetwork();

  SerialMon.println("SIM status: " + String(simStatus));
  SerialMon.print("Signal quality: ");
  SerialMon.println(modem.getSignalQuality());

  SerialMon.println("Setting SMS mode to text...");
  modem.sendAT("+CMGF=1");
  updateSerial();
  delay(100);
  if (!modem.waitResponse(1000)) {
    SerialMon.println("Failed to set SMS mode.");
    return;
  }

  SerialAT.println("AT+CNMI=2,2,0,0,0"); // Decides how newly arrived SMS messages should be handled
  updateSerial();

  SerialMon.println("Selecting SMS storage...");
  modem.sendAT("+CPMS=\"SM\",\"SM\",\"SM\"");
  if (!modem.waitResponse(1000)) {
    SerialMon.println("Failed to select SMS storage.");
    return;
  }

  SerialMon.println("Deleting all messages...");
  deleteAllSMS();  // 🧹 Clean all messages at boot

  SerialMon.println("Done!");



  // modem.sendAT("+CLIP=1"); // Enable Caller ID
  // modem.waitResponse(1000); // Not critical if it fails
}

void waitForNetwork(unsigned long timeout) {
  SerialMon.print("Connecting");
  unsigned long start = millis();
  while (!modem.isNetworkConnected() && millis() - start < timeout) {
    delay(1000);
    SerialMon.print(".");
  }
  SerialMon.println();

  if (modem.isNetworkConnected()) {
    SerialMon.println("Connected to network!");
    blink_internal_led(3, 200);
  } else {
    SerialMon.println("Still not connected.");
  }
}


bool sendSMS(const String& message, const String& number) {
  return modem.sendSMS(number, message);
}

bool isGSMReady() {
  return modem.isNetworkConnected();
}

bool callNumber(const String& phoneNumber) {
  SerialMon.print("Calling ");
  SerialMon.println(phoneNumber);
  if (modem.callNumber(phoneNumber)) {
    SerialMon.println("Call initiated.");
    callActive = true;
    callStartTime = millis();
    return true;
  } else {
    SerialMon.println("Failed to initiate call.");
    return false;
  }
}

void updateSerial()
{
  while (Serial.available())
  {
    SerialAT.write(Serial.read());//Forward what Serial received to Software Serial Port
  }
  while (SerialAT.available())
  {
    Serial.write(SerialAT.read());//Forward what Software Serial received to Serial Port
  }
}

void checkForIncomingSMS() {
  static String currentLine = "";
  static String senderNumber = "";
  static bool expectingMessage = false;

  while (SerialAT.available()) {
    char c = SerialAT.read();

    // Debugging: Print all characters as they arrive
    // Serial.println(c); 

    if (c == '\n') {
      currentLine.trim();

      if (expectingMessage) {
        String receivedMessage = currentLine;
        Serial.println("Sender: " + senderNumber);
        Serial.println("Message: " + receivedMessage);
        receivedMessage.toCharArray(smsBuffer, sizeof(smsBuffer));
        handleIncomingCommand(senderNumber, receivedMessage);
        deleteLastSMS(); // Delete after handling
        expectingMessage = false;
      } else if (currentLine.startsWith("+CMT:")) {
        // Extract the sender number
        int firstQuote = currentLine.indexOf('"');
        int secondQuote = currentLine.indexOf('"', firstQuote + 1);
        senderNumber = currentLine.substring(firstQuote + 1, secondQuote);
        Serial.println("Expecting message from: " + senderNumber); // Debugging
        expectingMessage = true;
      }

      currentLine = "";
    } else {
      currentLine += c;
    }
  }
}


void deleteLastSMS() {
  // Deletes SMS at index 1 (works in this setup since new SMS always lands at index 1 in direct mode)
  SerialAT.println("AT+CMGD=1");
  delay(100);
}

void deleteAllSMS() {
  // Loop over a reasonable range to ensure cleanup
  for (int i = 1; i <= 5; i++) {
    SerialAT.print("AT+CMGD=");
    SerialAT.println(i);
    delay(100);
  }
}

