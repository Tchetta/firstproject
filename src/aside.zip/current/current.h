#ifndef DHT_H
#define DHT_H

void setCurrentPin(int pin);
float currentValue(int pin);

#endif