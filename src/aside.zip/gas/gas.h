#ifndef GAS_H
#define GAS_H

// void handleGasDetection2();
void handleGasDetection();
void initGasSensor();
float readGasLPG();
float readGasCO();
float readGasSmoke();

#endif

