#ifndef ASIDE_H
#define ASIDE_H

void blink_internal_led(int count = 3, int delay = 300);
void setBlinkPin();
void setInternalBlinkPin();
void handleIncomingCommand(const String &sender, const String &message);

#endif