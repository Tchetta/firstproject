#include <Arduino.h>
#include "aside.h"
#include "../http/http_app.h"

void blink_internal_led(int count, int delayTIme) {
    pinMode(13, OUTPUT);

    int i = 0;
    while (i != count) {
        digitalWrite(13, HIGH);
        delay(delayTIme);
        digitalWrite(13, LOW);
        delay(delayTIme);

        i++;
    }
}

void setBlinkPin() {
    pinMode(13, OUTPUT);
}
void setInternalBlinkPin() {
    pinMode(13, OUTPUT);
}

void handleIncomingCommand(const String &sender, const String &message) {
    // Define trusted numbers
    const char* trustedNumbers[] = {
      "+237653997220",  // Replace with your phone number(s)
      "653997220",  // Replace with your phone number(s)
      "+237620637397",
      "620637397"
    };
  
    bool authorized = false;
    for (const char* number : trustedNumbers) {
      if (sender == String(number)) {
        authorized = true;
        break;
      }
    }
  
    if (!authorized) {
      Serial.println("Unauthorized sender. Ignoring command.");
      return;
    }
  
    // Match commands (basic)
    if (message.equalsIgnoreCase("LIGHT ON")) {
      Serial.println("Turning light ON...");
      sendSerialLogToServer("Turning light ON...");
      setLedState("on");
      // digitalWrite(LED_BUILTIN, HIGH); // Example
    } else if (message.equalsIgnoreCase("LIGHT OFF")) {
      Serial.println("Turning light OFF...");
      sendSerialLogToServer("Turning light OFF...");
      setLedState("off");
      // digitalWrite(LED_BUILTIN, LOW);
    } else if (message.equalsIgnoreCase("REBOOT")) {
      Serial.println("Rebooting...");
      sendSerialLogToServer("Rebooting...");
      ESP.restart(); // Only on ESP32/ESP8266
    } else {
      Serial.println("Unknown command.");
    }
  }