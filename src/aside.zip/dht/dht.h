#ifndef DHT_H
#define DHT_H

void dhtSetup();
void dhtespSetup();
void dhtread();
void readDHT();

#endif
/* 
#ifndef DHT_MANAGER_H
#define DHT_MANAGER_H

#include <DHTesp.h>
#include <Ticker.h>

// === Configuration Constants ===
#define DHT_PIN         21      // GPIO for DHT11 data
#define DHT_READ_INTERVAL 20    // Interval in seconds

// === Externally visible functions ===
bool initDHTManager();                // Initializes sensor, task, and ticker
bool readDHTSensor();                 // Manually trigger reading (if needed)
void triggerRead();                   // Triggered by Ticker to wake up task

// === Optional: External variables (if needed elsewhere) ===
extern ComfortState comfort;

#endif // DHT_MANAGER_H
 */