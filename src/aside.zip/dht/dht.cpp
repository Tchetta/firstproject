#include <DHT.h>
#include <DHTesp.h>
#define DHT11_PIN  14 // ESP32 pin GPIO21 connected to DHT11 sensor
#define DHT_PIN 21 // Use any suitable GPIO

DHT dht11(DHT11_PIN, DHT11);

void dhtSetup() {
    dht11.begin();
}

void dhtread() {
    float humi  = dht11.readHumidity();
  // read temperature in Celsius
  float tempC = dht11.readTemperature();
  // read temperature in Fahrenheit
  float tempF = dht11.readTemperature(true);

  // check whether the reading is successful or not
  if ( isnan(tempC) || isnan(tempF) || isnan(humi)) {
    Serial.println("Failed to read from DHT11 sensor!");
  } else {
    Serial.print("Humidity: ");
    Serial.print(humi);
    Serial.print("%");

    Serial.print("  |  ");

    Serial.print("Temperature: ");
    Serial.print(tempC);
    Serial.println("°C");
  }
}

DHTesp dht;

void dhtespSetup() {
  dht.setup(DHT_PIN, DHTesp::DHT11); // Or DHTesp::DHT11 if using DHT11
}

void readDHT() {
  TempAndHumidity data = dht.getTempAndHumidity();

  if (dht.getStatus() != 0) {
    Serial.print("DHT Error: ");
    Serial.println(dht.getStatusString());
    return;
  }

  Serial.print("Humidity: ");
  Serial.print(data.humidity, 1);
  Serial.print("%  |  ");

  Serial.print("Temperature: ");
  Serial.print(data.temperature, 1);
  Serial.println("°C");

  // Optional: Add logic for alerts or thresholds here
}