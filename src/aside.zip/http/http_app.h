#ifndef HTTP_H
#define HTTP_H

#include <Arduino.h>

void setupESPApp(char* ssid, char* password);
void handleClientESPApp();
void checkLEDStateFromServer();
void sendSerialLogToServer(String message);
void setLedState(String state);

#endif
