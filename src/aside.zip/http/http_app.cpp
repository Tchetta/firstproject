// esp32_http_app.cpp - ESP32 as client, communicates with PC server via HTTP

// #include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include "http_app.h"

#define LED_PIN 13

const char* serverURL = "http://192.168.115.240:8888/esp32tests/api"; // Replace with your PC's local IP

bool ledState = false;
unsigned long lastCheck = 0;
unsigned long lastSendLog = 0;

void setupESPApp(char* ssid, char* password) {
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);


  Serial.println("");
  Serial.println("IP address: " + WiFi.localIP());
  Serial.println("\nConnected to WiFi.");
}

void handleClientESPApp() {
  if (millis() - lastCheck > 3000) {
    lastCheck = millis();
    checkLEDStateFromServer();
  }
}

void checkLEDStateFromServer() {
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(String(serverURL) + "/led_state.php");
    int httpCode = http.GET();

    if (httpCode == 200) {
      String payload = http.getString();
      payload.trim();
      if (payload == "on") {
        digitalWrite(LED_PIN, HIGH);
        ledState = true;
      } else {
        digitalWrite(LED_PIN, LOW);
        ledState = false;
      }
    }
    http.end();
  }
}

void setLedState(String state) {
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(String(serverURL) + "/set_led.php?state=" + state);
    int httpCode = http.GET();

    if (httpCode == 200) {
      Serial.println("LED set!");
      sendSerialLogToServer("LED set!");
    }
    http.end();
  }
}

void sendSerialLogToServer(String message) {
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(String(serverURL) + "/serial_log.php");
    http.addHeader("Content-Type", "application/x-www-form-urlencoded");

    String postData = "log=" + message;
    int httpCode = http.POST(postData);
    http.end();
  }
}
